import React, { useRef, useEffect } from 'react';

const LoadMore = () => {
  const listInnerRef = useRef();

  const onScroll = () => {
    if (listInnerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = listInnerRef.current;
      if (scrollTop + clientHeight === scrollHeight) {
        // TO SOMETHING HERE
        console.log('Reached bottom');
      }
    }
  };

  return (
    <div style={{ width: 30, height: 30 }}>
      <div
        className="list-inner"
        onScroll={() => onScroll()}
        ref={listInnerRef}
      >
        Load more
      </div>
    </div>
  );
};

export default LoadMore;
