export { default as NFTGallery } from './App';
