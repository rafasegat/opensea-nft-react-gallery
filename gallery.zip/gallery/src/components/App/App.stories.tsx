import React from 'react';
import App from './App';

export default {
  component: App,
  title: 'components/NFT Gallery'
};

export const Default = () => <App />;
