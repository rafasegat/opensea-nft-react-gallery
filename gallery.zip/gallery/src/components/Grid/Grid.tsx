import React, { useRef } from 'react';
import AnimatedNumbers from 'react-animated-numbers';
import LoadMore from '../../components/LoadMore/LoadMore';
import Skeleton from './Grid.skeleton';
import { useGlobalContext } from '../../contexts/GlobalContext';
import styles from './Grid.module.scss';

type TypeProps = {
  collection: TypeCollection;
};

const Grid = ({ collection }: TypeProps) => {
  const { globalState, globalDispatch } = useGlobalContext();
  const { filter } = globalState;
  const { isLoading } = globalState;

  const { assets } = collection;

  if (isLoading && !assets)
    return (
      <div className={styles.component}>
        <Skeleton />
      </div>
    );

  const assetsFiltered = Boolean(filter.length)
    ? assets.filter((asset) => {
        return filter.some((f) => {
          const filterTraitType = JSON.parse(f.value).trait_type;
          const filterValue = JSON.parse(f.value).value;
          return asset.traits.some(
            (t) => t.trait_type === filterTraitType && t.value === filterValue
          );
        });
      })
    : assets;

  return (
    <div className={styles.component}>
      <div className={styles.header}>
        <h2 className={styles.title}>{collection.name}</h2>
        <span className={styles['title-divider']}>//</span>
        <AnimatedNumbers
          animateToNumber={assetsFiltered.length}
          fontStyle={{ fontSize: 32 }}
        ></AnimatedNumbers>
      </div>

      <div className={styles['filters-selected']}>
        <h3 className={styles['filters-selected-title']}>
          FILTERS ({filter.length})
        </h3>
        {Boolean(filter.length) && (
          <ul className={styles['filters-selected-list']}>
            {filter.map(({ value, label }) => {
              const parsed = JSON.parse(value);
              const labelF = `${parsed.trait_type}: ${[parsed.value]} `;
              return (
                <li className={styles['filters-selected-list-item']}>
                  <button
                    type="button"
                    className={styles['filters-selected-btn-item']}
                    onClick={() => {
                      globalDispatch({
                        filter: filter.filter((f) => f.value !== value)
                      });
                    }}
                  >
                    <span>{labelF}</span>
                    <svg stroke="currentColor" fill="none" viewBox="0 0 8 8">
                      <path
                        stroke-linecap="round"
                        stroke-width="1.5"
                        d="M1 1l6 6m0-6L1 7"
                      ></path>
                    </svg>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <ul className={styles.list}>
        {assetsFiltered.map((asset: TypeCollectionAsset) => (
          <li key={asset.id} className={styles['list-item']}>
            <a
              href={asset.permalink}
              target="_blank"
              className={styles['list-item-link']}
            >
              <div className={styles['list-item-wrapper']}>
                <div className={styles['image']}>
                  <img src={asset.image_url} className={styles['image-src']} />
                </div>
                <div className={styles.content}>
                  <span>{asset.name}</span>
                </div>
              </div>
            </a>
          </li>
        ))}
      </ul>
      <LoadMore />
    </div>
  );
};

export default Grid;
